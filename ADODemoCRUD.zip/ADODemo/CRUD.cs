﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ADODemo
{
    class CRUD
    {
        static void Main(string[] args)
        {
            SqlConnection con;
            string connectionstring = @"Data Source=CharanrajGoud;Initial Catalog=Employee;Integrated Security=True";
            con = new SqlConnection(connectionstring);
            con.Open(); 
            try
            {
                Console.WriteLine("Connection Established");                               
                string ans;
                do
                {
                    Console.WriteLine("select from the option \n1.creation \n2.retrieve \n3.update \ndelete");
                    int choice = int.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:

                            Console.WriteLine("Enter Emp Id:");
                            int EmpId = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Emp Name:");
                            string EmpName = Console.ReadLine();
                            Console.WriteLine("Enter Emp Salary:");
                            int EmpSalary = int.Parse(Console.ReadLine());
                            string query = "insert into Employee(Id, Empname, Empsalary) values(" + EmpId + ", '" + EmpName + "', " + EmpSalary + ")";
                            SqlCommand insertcommand = new SqlCommand(query, con);
                            insertcommand.ExecuteNonQuery();
                            Console.WriteLine("data is inserted successfull");

                            break;
                        case 2:

                            Console.WriteLine("Employee data");
                            string RetrieveQuery = "select * from Employee; ";
                            SqlCommand displaycommand = new SqlCommand(RetrieveQuery, con);
                            SqlDataReader reader = displaycommand.ExecuteReader();
                            while (reader.Read())
                            {
                                Console.WriteLine("id: " + reader.GetValue(0).ToString());
                                Console.WriteLine("name: " + reader.GetValue(1).ToString());
                                Console.WriteLine("salary: " + reader.GetValue(2).ToString());

                            }
                            reader.Close();
                            break;

                        case 3:

                            Console.WriteLine("Enter Employee ID:");
                            int Emp_Id = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Employee Name:");
                            string Emp_Name=Console.ReadLine();
                            Console.WriteLine("Enter Employee Salary:");
                            int Emp_Salary = int.Parse(Console.ReadLine());
                            string updateQuery = "UPDATE Employee SET Empsalary=" + Emp_Salary + " WHERE Id=" + Emp_Id + ";";
                            SqlCommand updatecommand = new SqlCommand(updateQuery, con);
                            updatecommand.ExecuteNonQuery();
                            Console.WriteLine("data updated sucessfully");
                            break;

                        case 4:
                            Console.WriteLine("Enter Employee Id:");
                            int Id = int.Parse(Console.ReadLine());
                            string deleteQuery = "DELETE FROM Employee WHERE Id=" + Id + ";";
                            SqlCommand deletecommand = new SqlCommand(deleteQuery, con);
                            deletecommand.ExecuteNonQuery();
                            Console.WriteLine("Deleted Successfully");
                            break;

                        default:
                            Console.WriteLine("wrong input");
                            break;

                    }
                    Console.WriteLine("do you want to continue");
                    ans = Console.ReadLine();
                }
                while (ans != "no");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }            
                
    }
}
