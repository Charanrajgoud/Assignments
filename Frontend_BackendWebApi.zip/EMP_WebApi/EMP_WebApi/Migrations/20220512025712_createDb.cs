﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EMP_WebApi.Migrations
{
    public partial class createDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
