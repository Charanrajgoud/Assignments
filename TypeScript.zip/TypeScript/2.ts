class Account {
    id: number;
    name: string;
    balance: number;
    constructor(id: number, name: string, balance: number) {
        this.id = id;
        this.name = name;
        this.balance = balance;
    }
}

class SavingAccount extends Account {
    interest: number;
    cash_credit: number;
    constructor(id: number, name: string, balance: number, interest: number, cash_credit: number) {
        super(id, name, balance);
        this.interest = interest;
        this.cash_credit = cash_credit;
    }
    TotalAmount(): number {
        return this.balance;
    }
}

class CurrentAccount extends Account {
    interest: number;
    cash_credit: number;
    constructor(id: number, name: string, balance: number, interest: number, cash_credit: number) {
        super(id, name, balance);
        this.interest = interest;
        this.cash_credit = cash_credit;
    }
    TotalAmount(): number {
        return this.balance;
    }
}

var sa: SavingAccount = new SavingAccount(101, "Charan", 400000, 5, 10000);
var sa1: SavingAccount = new SavingAccount(102, "Varun", 40000, 6, 1000);
var ca: CurrentAccount = new CurrentAccount(103, "Arun", 4000, 6, 100);
var ca2: CurrentAccount = new CurrentAccount(104, "Sharath", 400, 6, 10);
console.log(sa.TotalAmount());
console.log(sa1.TotalAmount());
console.log(ca.TotalAmount());
console.log(ca2.TotalAmount());